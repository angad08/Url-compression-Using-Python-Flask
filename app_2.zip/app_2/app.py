from flask import Flask, render_template, request,redirect,url_for
import hashlib as hlb
import pyperclip as pc
import datetime as dt
from flask_sqlalchemy import SQLAlchemy
import webbrowser as wbb
url_date=dt.datetime.now()
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql+pymysql://root:@localhost/urlhistory"
db = SQLAlchemy(app)
class urllog(db.Model):
    ID = db.Column('ID', db.Integer, primary_key = True)
    ORIGINAL_LINK = db.Column(db.String(100))
    COMPRESSED_LINK = db.Column(db.String(50))  
    DATE_ADDED = db.Column(db.DATE)
    TIME_ADDED = db.Column(db.TIME)

    def __init__(self, ORIGINAL_LINK, COMPRESSED_LINK, DATE_ADDED,TIME_ADDED):
        self.ORIGINAL_LINK = ORIGINAL_LINK
        self.COMPRESSED_LINK = "http://127.0.0.1:5000/"+COMPRESSED_LINK
        self.DATE_ADDED = DATE_ADDED
        self.TIME_ADDED = TIME_ADDED

@app.route('/')
def home_get():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def home_post():
    original_url = request.form.get('in_1')
    shorten_url =hlb.md5(original_url.encode("utf-8")).hexdigest()[:9][::-1]
    URL=urllog(ORIGINAL_LINK=original_url,COMPRESSED_LINK=shorten_url,DATE_ADDED=url_date.strftime("%Y-%m-%d"),TIME_ADDED=url_date.strftime("%H:%M:%S"))
    db.session.add(URL)  
    db.session.commit()
    return render_template('short.html',v="http://127.0.0.1:5000/"+shorten_url)
@app.route("/short",methods=["POST"])
def copyToClipboard():
    surlink=request.form.get("surl")
    pc.copy(surlink)
    return render_template("short.html",c="Copied")
@app.route('/history')
def history_get():
    getHistory=db.session.execute("Select * from urllog")
    return render_template('history.html', data=getHistory)
@app.route("/<link>")
def direct(link):
    for i in db.session.execute("SELECT ORIGINAL_LINK FROM URLLOG WHERE COMPRESSED_LINK='{}'".format("http://127.0.0.1:5000/"+link)):
        return redirect(i[0])
if __name__ == "__main__":
    app.run(debug=True)