from flask import Flask, render_template, request
import random
import pyshorteners as ps
import pymysql
import pyperclip as pc
import datetime as dt
url_date=dt.datetime.now()
db=pymysql.connect("localhost","root","","urlhistory");
rs=db.cursor()
app = Flask(__name__)

data = {}

######################################

@app.route('/')
def home_get():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def home_post():
    original_url = request.form.get('in_1')
    shorten_url = ps.Shortener().tinyurl.short(original_url)
    inlink="INSERT INTO URLLOG(ORIGINAL_LINK,COMPRESSED_LINK,DATE_ADDED,TIME_ADDED) VALUES('{}','{}','{}','{}')".format(original_url,shorten_url,url_date.strftime("%Y-%m-%d"),url_date.strftime("%H:%M:%S"))
    rs.execute(inlink)
    db.commit()
    return render_template('short.html',v=shorten_url)
@app.route("/short",methods=["POST"])
def copyToClipboard():
    surlink=request.form.get("surl")
    pc.copy(surlink)
    return render_template("short.html",c="Copied")
@app.route('/history')
def history_get():
    getHistory="SELECT * FROM URLLOG"
    rs.execute(getHistory)
    data=rs.fetchall()
    return render_template('history.html', data=data)

######################################


if __name__ == "__main__":
    app.run(debug=True)