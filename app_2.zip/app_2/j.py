import pyshorteners as ps
class supressLink:
    def supres(self,link):
        self.link=link
        s=ps.Shortener()
        print(s.tinyurl.short(self.link))



x=supressLink()
x.supres("www.facebook.com")
print(x.link)