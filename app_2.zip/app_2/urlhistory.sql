-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.21-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for urlhistory
CREATE DATABASE IF NOT EXISTS `urlhistory` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `urlhistory`;

-- Dumping structure for table urlhistory.students
CREATE TABLE IF NOT EXISTS `students` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `orl` varchar(100) DEFAULT NULL,
  `cpl` varchar(50) DEFAULT NULL,
  `dts` varchar(200) DEFAULT NULL,
  `times` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table urlhistory.students: ~2 rows (approximately)
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` (`ID`, `orl`, `cpl`, `dts`, `times`) VALUES
	(1, 'www.google.com', 'aspds', '123', '1234'),
	(2, 'www.google.com', 'aspds', '123', '1234');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;

-- Dumping structure for table urlhistory.urllog
CREATE TABLE IF NOT EXISTS `urllog` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ORIGINAL_LINK` varchar(50) NOT NULL,
  `COMPRESSED_LINK` varchar(50) NOT NULL,
  `DATE_ADDED` date NOT NULL,
  `TIME_ADDED` time NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table urlhistory.urllog: ~3 rows (approximately)
/*!40000 ALTER TABLE `urllog` DISABLE KEYS */;
INSERT INTO `urllog` (`ID`, `ORIGINAL_LINK`, `COMPRESSED_LINK`, `DATE_ADDED`, `TIME_ADDED`) VALUES
	(39, 'https://www.linkedin.com/in/angad-kadam-03b606159/', 'http://127.0.0.1:5000/dc75bef58', '2021-10-28', '18:28:55'),
	(40, 'https://github.com/angad08', 'http://127.0.0.1:5000/86e77dae5', '2021-10-28', '18:31:12'),
	(41, 'https://www.linkedin.com/in/angad-kadam-03b606159/', 'http://127.0.0.1:5000/dc75bef58', '2021-10-28', '18:31:12');
/*!40000 ALTER TABLE `urllog` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
